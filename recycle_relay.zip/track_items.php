<?php
// track_items.php
$host = "localhost";
$username = "root";
$password = ""; // change if you set a password in phpMyAdmin
$database = "user_authentication"; // <-- replace with your DB name

$conn = new mysqli($host, $username, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch items
$sql = "SELECT title, description, category,  image_path, status, uploaded_at FROM recycle_items ORDER BY uploaded_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Track Your Items - Recycle Relay</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8fdf8;
      padding: 30px;
    }

    h2 {
      color: #28a745;
      text-align: center;
      margin-bottom: 30px;
    }

    .item {
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      padding: 20px;
      margin-bottom: 20px;
      display: flex;
      gap: 20px;
      align-items: center;
    }

    .item img {
      width: 120px;
      height: 120px;
      object-fit: cover;
      border-radius: 8px;
      border: 1px solid #ccc;
    }

    .info {
      flex-grow: 1;
    }

    .info h3 {
      margin: 0 0 5px;
      color: #333;
    }

    .info p {
      margin: 4px 0;
      font-size: 0.95rem;
    }

    .status {
      font-weight: bold;
      color: #007bff;
    }
  </style>
</head>
<body>
  <h2>Track Your Uploaded Items</h2>

  <?php
  if ($result && $result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
          // $imagePath = 'uploads/' . htmlspecialchars($row["image_path"]);

          echo '<div class="item" style="border:1px solid #ccc; margin:10px; padding:10px; display:flex;">';
          if (!empty($row['image_path'])) {
            echo "<img src='" . htmlspecialchars($row['image_path']) . "' alt='Image' />";
        }
          echo '<div class="info" style="margin-left:15px;">';
          echo '<h3>' . htmlspecialchars($row["title"]) . '</h3>';
          echo '<p><strong>Category:</strong> ' . htmlspecialchars($row["category"]) . '</p>';
          echo '<p><strong>Description:</strong> ' . htmlspecialchars($row["description"]) . '</p>';
          echo '<p><strong>Status:</strong> <span class="status">' . htmlspecialchars($row["status"]) . '</span></p>';
          
          echo '<p><strong>Uploaded At:</strong> ' . htmlspecialchars($row["uploaded_at"]) . '</p>';
          echo '</div></div>';
      }
  } else {
      echo "<p style='text-align:center;'>No items uploaded yet.</p>";
  }

  $conn->close();
  ?>
</body>

</html>
